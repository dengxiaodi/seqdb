<?php

namespace Admin\Controller;

class SampleController extends AdminController {
    public function index(){
        echo "sample";
    }
}